<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FotoProfilController extends Controller
{
    //

}
