<?php

namespace App\Http\Controllers;

use App\Helpers\Helper;
use App\Helpers\Variable;
use App\Models\Gapoktan;
use App\Models\Produk;
use App\Models\ThubnailProduk;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ProdukController extends Controller
{
    public function lihatProdukGapoktan(Request $request)
    {
        $state = false;
        if ($request->user_id) {
            $gapoktan = Gapoktan::where('user_id', $request->user_id)->first();
            if(!$gapoktan) {
                return $this->resp(null, Variable::NOT_FOUND, false, 406);
            }
            $state = true;
        }
        $data = Produk::leftJoin('thubnail_produks', 'produks.id', '=', 'thubnail_produks.produk_id')
        ->join('kategoris', 'kategoris.id', '=', 'produks.kategori_id')
        ->where('produks.gapoktan_id', $state ? $gapoktan->id : $request->gapoktan_id)
        ->select(DB::raw('produks.*, thubnail_produks.nama as nama_thumbnail, produks.id as id, kategoris.nama as nama_kategori'))
        ->orderBy('produks.id', 'DESC');
        return $this->getPaginate($data, $request, [
            'produks.kategori_id', 'kategoris.nama','produks.nama', 'produks.kode', 'produks.stok', 'produks.harga', 'produks.deskripsi', 'produks.status'
        ]);
    }

    public function lihatSemuaProduk(Request $request)
    {
        $data = Produk::join('gapoktans', 'gapoktans.id', '=', 'produks.gapoktan_id')
        ->leftJoin('thubnail_produks', 'produks.id', '=', 'thubnail_produks.produk_id')
        ->select(DB::raw('produks.*, thubnail_produks.nama as nama_thumbnail, produks.id as id, gapoktans.nama as nama_gapoktan'))
        ->orderBy('produks.id', 'DESC');
        return $this->getPaginate($data, $request, ['produks.nama', 'gapoktans.nama']);
    }

    public function lihatProdukCostumer(Request $request)
    {
        $data = Produk::leftJoin('thubnail_produks', 'thubnail_produks.produk_id', '=', 'produks.id')
        ->where('produks.kategori_id', $request->kategori_id)
        ->select(DB::raw('produks.*, produks.id as id, thubnail_produks.nama as nama_thumbnail'))
        ->orderBy('produks.id', 'DESC');
        return $this->getPaginate($data, $request, ['produks.nama']);
    }

    public function lihatSemuaProdukCostumer(Request $request)
    {
        $data = Produk::leftJoin('thubnail_produks', 'thubnail_produks.produk_id', '=', 'produks.id')
        ->leftJoin('gapoktans', 'gapoktans.id', '=', 'produks.gapoktan_id')
        ->select(DB::raw('gapoktans.*, produks.*, produks.id as id, produks.nama as nama_produk, thubnail_produks.nama as nama_thumbnail, gapoktans.nama as nama_gapoktan'))
        ->orderBy('produks.id', 'DESC');
        return $this->getPaginate($data, $request, ['produks.nama']);
    }

    public function tambahProduk(Request $request)
    {
        $input = $request->only(['gapoktan_id', 'kategori_id', 'nama', 'berat', 'stok', 'harga', 'deskripsi', 'foto']);
        $validator = Validator::make($input, [
            'gapoktan_id' => 'numeric',
            'kategori_id' => 'required|numeric',
            'nama' => 'required|string',
            'berat' => 'required|numeric',
            'stok' => 'required|numeric',
            'harga' => 'required|numeric',
            'deskripsi' => 'required|string',
            'foto' => 'mimes:jpeg,png,jpg|max:5048'
        ], Helper::messageValidation());
        if ($validator->fails()) {
            return $this->resp(Helper::generateErrorMsg($validator->errors()->getMessages()), Variable::FAILED, false, 406);
        }
        $state = false;
        if ($request->user_id) {
            $gapoktan = Gapoktan::where('user_id', $request->user_id)->first();
            if(!$gapoktan) {
                return $this->resp(null, Variable::NOT_FOUND, false, 406);
            }
            $state = true;
        }
        $kode1 = str_random(8);;
        $kode2 = rand(100,999);
        $produk = Produk::create([
            'gapoktan_id' => $state ? $gapoktan->id : $input['gapoktan_id'],
            'kategori_id' => $input['kategori_id'],
            'nama' => $input['nama'],
            'berat' => $input['berat'],
            'kode' => $kode1."-".$kode2,
            'stok' => $input['stok'],
            'harga' => $input['harga'],
            'deskripsi' => $input['deskripsi']
        ]);
        if($request->hasFile('foto')){
            try {
                $this->storeFile(new ThubnailProduk(), $request->file('foto'), Variable::TPDK, $produk->id);
            } catch (\Throwable $th) {
                return $this->resp(null, $th);
            }
        }
        return $this->resp($produk);
    }

    public function ubahProduk(Request $request, $id)
    {
        $produk = Produk::find($id);
        if (!$produk) {
            return $this->resp(null, Variable::NOT_FOUND, false, 406);
        }
        $input = $request->only(['kategori_id', 'nama', 'berat', 'stok', 'harga', 'deskripsi', 'status', 'foto']);
        $validator = Validator::make($input, [
            'kategori_id' => 'required|numeric',
            'nama' => 'required|string',
            // 'kode' => 'required|string',
            'berat' => 'required|numeric',
            'stok' => 'required|numeric',
            'harga' => 'required|numeric',
            'deskripsi' => 'required|string',
            // 'status' => 'required|boolean',
            'foto' => 'mimes:jpeg,png,jpg|max:2048'
        ], Helper::messageValidation());
        if ($validator->fails()) {
            return $this->resp(Helper::generateErrorMsg($validator->errors()->getMessages()), Variable::FAILED, false, 406);
        }
        $produk->update([
            'kategori_id' => $input['kategori_id'],
            'nama' => $input['nama'],
            'berat' => $input['berat'],
            // 'kode' => $input['kode'],
            'stok' => $input['stok'],
            'harga' => $input['harga'],
            'deskripsi' => $input['deskripsi'],
            // 'status' => $input['status']
        ]);
        if(!empty($request->foto)){
            $this->storeFile(new ThubnailProduk(), $request->foto, Variable::TPDK, $id);
        }
        return $this->resp($produk);
    }

    public function changeStatusProduk(Request $request, $id)
    {
        $input = $request->only(['status']);
        $validator = Validator::make($input, [
            'status' => 'required|numeric',
        ], Helper::messageValidation());
        if ($validator->fails()) {
            return $this->resp(Helper::generateErrorMsg($validator->errors()->getMessages()), Variable::FAILED, false, 406);
        }
        try {
            Produk::find($id)->update([
                'status' => $input['status']
            ]);
        } catch (\Throwable $e) {
            return $this->resp(null, $e->getMessage(), false, 404);
        }
        return $this->resp();
    }

    public function hapusProduk($id)
    {
        try {
            Produk::find($id)->delete();
        } catch (\Throwable $e) {
            return $this->resp(null, $e->getMessage(), false, 404);
        }
        return $this->resp();
    }
}
