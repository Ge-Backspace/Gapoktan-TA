<html>
<head>
	<title>Export Laporan Tandur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
</head>
<body>

	<div class="container">
		<center>
			<h4>LAPORAN TANDUR POKTAN <?php echo e(strtoupper($poktan->nama)); ?> <?php echo e(date('d-m-Y', strtotime($tanggal_awal))); ?> - <?php echo e(date('d-m-Y', strtotime($tanggal_akhir))); ?></h4>
		</center>
        <p><b>Total : <?php echo e(count($datas)); ?> data</b></p>
		<table class='table table-bordered'>
			<thead>
				<tr>
					<th>No</th>
					<th>Tanaman</th>
					<th>Luas Tandur</th>
					<th>Tanggal Tandur</th>
					<th>Tanggal Panen</th>
				</tr>
			</thead>
			<tbody>
				<?php $i=1 ?>
				<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($i++); ?></td>
					<td><?php echo e($d->tanaman); ?></td>
					<td><?php echo e($d->luas_tandur); ?> Hektar</td>
					<td><?php echo e(date('d-m-Y', strtotime($d->tanggal_tandur))); ?></td>
					<td><?php echo e(date('d-m-Y', strtotime($d->tanggal_panen))); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>

</body>
</html>
<?php /**PATH D:\TA\App\api\resources\views/tandurpoktan.blade.php ENDPATH**/ ?>